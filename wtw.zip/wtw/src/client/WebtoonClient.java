package client;

import controller.WebtoonController;

public class WebtoonClient {

	public static void main(String[] args) {
		
		WebtoonController app =new WebtoonController();
		app.appStart();
		
	}

}
